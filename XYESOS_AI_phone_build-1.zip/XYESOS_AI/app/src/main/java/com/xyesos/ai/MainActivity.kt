package com.xyesos.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val Bg = Color(0xFF09090D)
private val Panel = Color(0xFF15131D)
private val Purple = Color(0xFF9B7BFF)
private val TextMain = Color(0xFFF4F0FF)
private val Muted = Color(0xFFAAA3B8)

data class ChatMessage(val role: String, val content: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { XyesosApp() }
    }
}

@Composable
fun XyesosApp() {
    var endpoint by remember { mutableStateOf("https://api.openai.com/v1/chat/completions") }
    var model by remember { mutableStateOf("") }
    var apiKey by remember { mutableStateOf("") }
    var instructions by remember {
        mutableStateOf("Ты — полезный ИИ-помощник. Отвечай по-русски, пиши понятный и проверяемый код.")
    }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<ChatMessage>() }
    val scope = rememberCoroutineScope()

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Panel, primary = Purple,
            onBackground = TextMain, onSurface = TextMain
        )
    ) {
        Column(
            modifier = Modifier.fillMaxSize().background(Bg).padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("XYESOS AI", color = TextMain, fontSize = 25.sp)
                    Text("ТВОЙ ИИ • CHAT & CODE", color = Muted, fontSize = 11.sp)
                }
                TextButton(onClick = { showSettings = !showSettings }) {
                    Text(if (showSettings) "Скрыть настройки" else "Настройки", color = Purple)
                }
            }

            if (showSettings) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 12.dp)
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("ПОДКЛЮЧЕНИЕ МОДЕЛИ", color = Purple, fontSize = 12.sp)
                        OutlinedTextField(
                            value = endpoint, onValueChange = { endpoint = it },
                            label = { Text("API endpoint") }, singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = model, onValueChange = { model = it },
                            label = { Text("Название модели") }, singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = apiKey, onValueChange = { apiKey = it },
                            label = { Text("API key (не сохраняется)") },
                            singleLine = true, visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = instructions, onValueChange = { instructions = it },
                            label = { Text("Инструкции для ИИ") },
                            modifier = Modifier.fillMaxWidth(), minLines = 2
                        )
                        Text(
                            "Нужны endpoint, модель и API-ключ выбранного провайдера. Ключ хранится только в памяти экрана и очищается при закрытии приложения.",
                            color = Muted, fontSize = 11.sp
                        )
                    }
                }
            }

            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (messages.isEmpty()) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                            Column(Modifier.padding(16.dp)) {
                                Text("Добро пожаловать в XYESOS AI", color = TextMain, fontSize = 18.sp)
                                Spacer(Modifier.height(6.dp))
                                Text("Задай вопрос или попроси написать код. Для начала укажи параметры API в настройках.", color = Muted)
                            }
                        }
                    }
                }
                items(messages) { msg ->
                    val isUser = msg.role == "user"
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                    ) {
                        Card(
                            modifier = Modifier.fillMaxWidth(0.92f),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isUser) Color(0xFF29213D) else Panel
                            ),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Text(
                                text = msg.content,
                                color = TextMain,
                                modifier = Modifier.padding(13.dp)
                            )
                        }
                    }
                }
                if (busy) item { Text("XYESOS AI печатает…", color = Purple) }
            }

            if (error.isNotBlank()) {
                Text(error, color = Color(0xFFFF8A8A), fontSize = 12.sp, modifier = Modifier.padding(vertical = 5.dp))
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                OutlinedTextField(
                    value = input, onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Напиши сообщение…") },
                    maxLines = 5
                )
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = {
                        val prompt = input.trim()
                        if (prompt.isNotEmpty() && !busy) {
                            if (endpoint.isBlank() || model.isBlank() || apiKey.isBlank()) {
                                error = "Заполни endpoint, модель и API key в настройках."
                            } else {
                                input = ""
                                error = ""
                                messages.add(ChatMessage("user", prompt))
                                busy = true
                                scope.launch {
                                    try {
                                        val answer = withContext(Dispatchers.IO) {
                                            requestChat(endpoint.trim(), model.trim(), apiKey.trim(), instructions, messages.toList())
                                        }
                                        messages.add(ChatMessage("assistant", answer))
                                    } catch (e: Exception) {
                                        error = "Ошибка запроса: ${e.message ?: "проверь настройки API и интернет"}"
                                    } finally {
                                        busy = false
                                    }
                                }
                            }
                        }
                    },
                    enabled = !busy,
                    modifier = Modifier.height(56.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Purple)
                ) { Text("➤", color = Color.White) }
            }
        }
    }
}

private fun requestChat(
    endpoint: String,
    model: String,
    apiKey: String,
    instructions: String,
    history: List<ChatMessage>
): String {
    val url = URL(endpoint)
    val connection = (url.openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        connectTimeout = 20000
        readTimeout = 60000
        doOutput = true
        setRequestProperty("Content-Type", "application/json")
        setRequestProperty("Authorization", "Bearer $apiKey")
    }

    val messageArray = JSONArray()
    messageArray.put(JSONObject().put("role", "system").put("content", instructions))
    history.forEach { messageArray.put(JSONObject().put("role", it.role).put("content", it.content)) }

    val body = JSONObject()
        .put("model", model)
        .put("messages", messageArray)
        .put("temperature", 0.7)

    connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
    val status = connection.responseCode
    val stream = if (status in 200..299) connection.inputStream else connection.errorStream
    val response = stream.bufferedReader().use { it.readText() }
    connection.disconnect()

    if (status !in 200..299) {
        throw IllegalStateException("HTTP $status: ${response.take(500)}")
    }
    val json = JSONObject(response)
    return json.getJSONArray("choices")
        .getJSONObject(0)
        .getJSONObject("message")
        .getString("content")
}
